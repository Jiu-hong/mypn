Build for Ubuntu 18.04.

To run on other platforms, build from https://github.com/CasperLabs/casper-node
 cd node
 cargo build --release

git commit hash: 2a92bae02ecbae7fb1eacca71e9066cb0ef4324a
